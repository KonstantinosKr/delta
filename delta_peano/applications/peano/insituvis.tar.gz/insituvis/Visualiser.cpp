#include "insituvis/Visualiser.h"



insituvis::Visualiser::Visualiser() {
}


insituvis::Visualiser::~Visualiser() {
}


void insituvis::Visualiser::display() {
  vtkRenderer*                renderer     = vtkRenderer::New();;
  vtkRenderWindow*            renderWindow = vtkRenderWindow::New();
  vtkRenderWindowInteractor*  interactor   = vtkRenderWindowInteractor::New();

  // Create window, renderer and interactor
  renderWindow->AddRenderer(renderer);
  interactor->SetRenderWindow(renderWindow);

  vtkSmartPointer< vtkCubeSource >      cube       = vtkSmartPointer< vtkCubeSource >::New();
  vtkSmartPointer< vtkPolyDataMapper >  cubeMapper = vtkSmartPointer< vtkPolyDataMapper >::New();

  vtkActor*           cubeActor  = vtkActor::New();

  cubeMapper->SetInputConnection(cube->GetOutputPort());
  cubeActor->SetMapper(cubeMapper);

  _actors.push_back(cubeActor);
//  cubeActor->GetProperty()->SetColor(0.9804,0.5020,0.4471);


//  renderer->AddActor(cubeActor);
  for (
    std::vector<vtkActor*>::iterator p = _actors.begin();
    p != _actors.end();
    p++
  ) {
    renderer->AddActor(*p);
  }

  // Display call
  renderWindow->Render();
  interactor->Start();

  // Clean up
  interactor->Delete();
  renderWindow->Delete();
  renderer->Delete();
}


void insituvis::Visualiser::writeToFile( const std::string& filename ) {

}


bool insituvis::Visualiser::isOpen() {
  return true;
}


void insituvis::Visualiser::clear() {
  for (
    std::vector<vtkActor*>::iterator p = _actors.begin();
    p != _actors.end();
    p++
  ) {
    (*p)->Delete();
  }
  _actors.clear();
}


tarch::plotter::griddata::unstructured::UnstructuredGridWriter::VertexWriter*   insituvis::Visualiser::createVertexWriter() {
  return new VertexWriter(*this);
}


tarch::plotter::griddata::unstructured::UnstructuredGridWriter::CellWriter*     insituvis::Visualiser::createCellWriter() {
  return new CellWriter(*this);
}


tarch::plotter::griddata::Writer::CellDataWriter*         insituvis::Visualiser::createCellDataWriter( const std::string& identifier, int recordsPerCell ) {
  return new CellDataWriter(identifier,*this,recordsPerCell);
}


tarch::plotter::griddata::Writer::VertexDataWriter*       insituvis::Visualiser::createVertexDataWriter( const std::string& identifier, int recordsPerVertex ) {
  return new VertexDataWriter(identifier,*this,recordsPerVertex);
}


insituvis::Visualiser::VertexWriter::VertexWriter(Visualiser& writer):
  _myWriter(writer) {
}


insituvis::Visualiser::VertexWriter::~VertexWriter() {
}


int insituvis::Visualiser::VertexWriter::plotVertex(const tarch::la::Vector<2,double>& position) {
  return 0;
}


int insituvis::Visualiser::VertexWriter::plotVertex(const tarch::la::Vector<3,double>& position) {
  return 0;
}


void insituvis::Visualiser::VertexWriter::close() {
}


insituvis::Visualiser::CellWriter::CellWriter(Visualiser& writer):
  _myWriter(writer) {
}


insituvis::Visualiser::CellWriter::~CellWriter() {
}


int insituvis::Visualiser::CellWriter::plotHexahedron(int vertexIndex[8]) {
  return 0;
}


int insituvis::Visualiser::CellWriter::plotQuadrangle(int vertexIndex[4]) {
  return 0;
}


int insituvis::Visualiser::CellWriter::plotLine(int vertexIndex[2]) {
  return 0;
}


int insituvis::Visualiser::CellWriter::plotTriangle(int vertexIndex[3]) {
  return 0;
}


int insituvis::Visualiser::CellWriter::plotPoint(int vertexIndex) {
  return 0;
}


void insituvis::Visualiser::CellWriter::close() {
}


insituvis::Visualiser::CellDataWriter::CellDataWriter(const std::string& dataIdentifier, Visualiser& writer, int recordsPerCell):
  _myWriter(writer) {
}


insituvis::Visualiser::CellDataWriter::~CellDataWriter() {
}


void insituvis::Visualiser::CellDataWriter::close() {
}


void insituvis::Visualiser::CellDataWriter::plotCell( int index, double value ) {
}


void insituvis::Visualiser::CellDataWriter::plotCell( int index, const tarch::la::Vector<2,double>& value ) {
}


void insituvis::Visualiser::CellDataWriter::plotCell( int index, const tarch::la::Vector<3,double>& value ) {
}


double insituvis::Visualiser::CellDataWriter::getMinValue() const {
  return 0.0;
}


double insituvis::Visualiser::CellDataWriter::getMaxValue() const {
  return 0.0;
}


void insituvis::Visualiser::CellDataWriter::assignRemainingCellsDefaultValues() {
}


insituvis::Visualiser::VertexDataWriter::VertexDataWriter(const std::string& dataIdentifier, Visualiser& writer, int recordsPerVertex):
  _myWriter(writer) {
}


insituvis::Visualiser::VertexDataWriter::~VertexDataWriter() {
}


void insituvis::Visualiser::VertexDataWriter::close() {
}


void insituvis::Visualiser::VertexDataWriter::plotVertex( int index, double value ) {
}


void insituvis::Visualiser::VertexDataWriter::plotVertex( int index, const tarch::la::Vector<2,double>& value ) {
}


void insituvis::Visualiser::VertexDataWriter::plotVertex( int index, const tarch::la::Vector<3,double>& value ) {
}


double insituvis::Visualiser::VertexDataWriter::getMinValue() const {
  return 0.0;
}


double insituvis::Visualiser::VertexDataWriter::getMaxValue() const {
  return 0.0;
}


void insituvis::Visualiser::VertexDataWriter::assignRemainingVerticesDefaultValues() {
}
