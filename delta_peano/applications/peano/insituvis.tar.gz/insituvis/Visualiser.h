// This file is part of the Peano project. For conditions of distribution and
// use, please see the copyright notice at www.peano-framework.org
#ifndef _INSITU_VIS_VISUALISER_H_
#define _INSITU_VIS_VISUALISER_H_


//
// According to VTK migration guide, these defines are required if we do not use cmake
// http://www.vtk.org/Wiki/VTK/VTK_6_Migration/Factories_now_require_defines
//
#define vtkRenderingCore_AUTOINIT 4(vtkInteractionStyle,vtkRenderingFreeType,vtkRenderingFreeTypeOpenGL,vtkRenderingOpenGL)
#define vtkRenderingVolume_AUTOINIT 1(vtkRenderingVolumeOpenGL)



#include "vtkRenderer.h"
#include "vtkRenderWindow.h"
#include "vtkRenderWindowInteractor.h"
#include "vtkActor.h"
#include "vtkCubeSource.h"
#include "vtkPolyDataMapper.h"
#include <vtkSmartPointer.h>

#include "tarch/plotter/griddata/unstructured/UnstructuredGridWriter.h"


namespace insituvis {
  class Visualiser;
}



/**
 * Visualiser
 *
 * This is a very simple visualiser that can be used like a standard Peano
 * plotter. However, it connects to the VTK library and thus allows for an
 * in-situ visualisation.
 *
 * @author Tobias Weinzierl
 */
class insituvis::Visualiser: public tarch::plotter::griddata::unstructured::UnstructuredGridWriter {
  private:
    std::vector<vtkActor*>     _actors;
  public:
    Visualiser();
    virtual ~Visualiser();

    /**
     * Opens a window and displays the setup
     */
    void display();

    virtual void writeToFile( const std::string& filename );

    /**
     * @return Whether writer is ready to accept data.
     */
    virtual bool isOpen();

    /**
     * Clear the writer, i.e. erase all the data. However, as the writer does
     * not track how many vertex and cell writers you've created, it's up to
     * you to ensure that none of these instances is left.
     */
    virtual void clear();

    virtual tarch::plotter::griddata::unstructured::UnstructuredGridWriter::VertexWriter*   createVertexWriter();

    /**
     * Caller has to destroy this instance manually. Do not create more than one
     * cell writer.
     */
    virtual tarch::plotter::griddata::unstructured::UnstructuredGridWriter::CellWriter*     createCellWriter();

    virtual tarch::plotter::griddata::Writer::CellDataWriter*         createCellDataWriter( const std::string& identifier, int recordsPerCell );
    virtual tarch::plotter::griddata::Writer::VertexDataWriter*       createVertexDataWriter( const std::string& identifier, int recordsPerVertex );

    class VertexWriter:
      public tarch::plotter::griddata::unstructured::UnstructuredGridWriter::VertexWriter {
      private:
        /**
         * The father class is a friend. There are no other friends.
         */
        friend class Visualiser;

        /**
         * Underlying writer.
         */
        Visualiser& _myWriter;

        VertexWriter(Visualiser& writer);

        /**
         * Do not copy a vertex writer.
         */
        VertexWriter(const VertexWriter& writer):
          _myWriter(writer._myWriter) {
          assertion(false);
        }
      public:
        virtual ~VertexWriter();

        virtual int plotVertex(const tarch::la::Vector<2,double>& position);
        virtual int plotVertex(const tarch::la::Vector<3,double>& position);

        virtual void close();
    };

    /**
     * Writes the element data.
     */
    class CellWriter:
      public tarch::plotter::griddata::unstructured::UnstructuredGridWriter::CellWriter {
      private:
        /**
         * The father class is a friend. There are no other friends.
         */
        friend class Visualiser;

        /**
         * Underlying writer.
         */
        Visualiser&  _myWriter;

        CellWriter(Visualiser& writer);

        CellWriter(const CellWriter& writer):
          _myWriter(writer._myWriter) {
          assertion(false);
        }
      public:
        virtual ~CellWriter();

        virtual int plotHexahedron(int vertexIndex[8]);

        virtual int plotQuadrangle(int vertexIndex[4]);

        virtual int plotLine(int vertexIndex[2]);

        virtual int plotTriangle(int vertexIndex[3]);

        virtual int plotPoint(int vertexIndex);

        virtual void close();
    };

    class CellDataWriter:
      public tarch::plotter::griddata::Writer::CellDataWriter {
        private:
          /**
           * The father class is a friend. There are no other friends.
           */
          friend class Visualiser;

          /**
           * Underlying writer.
           */
          Visualiser& _myWriter;

          CellDataWriter(const std::string& dataIdentifier, Visualiser& writer, int recordsPerCell);

          CellDataWriter(const CellDataWriter& copy):
            _myWriter(copy._myWriter) {
            assertion(false);
          }
      public:
        virtual ~CellDataWriter();

        virtual void close();

        virtual void plotCell( int index, double value );
        virtual void plotCell( int index, const tarch::la::Vector<2,double>& value );
        virtual void plotCell( int index, const tarch::la::Vector<3,double>& value );

        virtual double getMinValue() const;
        virtual double getMaxValue() const;

        virtual void assignRemainingCellsDefaultValues();
    };

    class VertexDataWriter:
      public tarch::plotter::griddata::Writer::VertexDataWriter {
        private:
        /**
         * The father class is a friend. There are no other friends.
         */
        friend class Visualiser;

        /**
         * Underlying writer.
         */
        Visualiser& _myWriter;

        VertexDataWriter(const std::string& dataIdentifier, Visualiser& writer, int recordsPerVertex);

        VertexDataWriter(const VertexDataWriter& copy):
          _myWriter(copy._myWriter) {
          assertion(false);
        }
      public:
        virtual ~VertexDataWriter();

        virtual void close();

        virtual void plotVertex( int index, double value );
        virtual void plotVertex( int index, const tarch::la::Vector<2,double>& value );
        virtual void plotVertex( int index, const tarch::la::Vector<3,double>& value );

        virtual double getMinValue() const;
        virtual double getMaxValue() const;

        virtual void assignRemainingVerticesDefaultValues();
    };
};

#endif
