#include "peano/grid/aspects/VertexStateAnalysis.h"


tarch::logging::Log  peano::grid::aspects::VertexStateAnalysis::_log( "peano::grid::aspects::VertexStateAnalysis" );
